package com.example.rostovlandmarksguide.welcome_screen

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import androidx.fragment.app.viewModels
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.checkSelfPermission
import androidx.core.os.bundleOf
import androidx.navigation.Navigation
import com.example.rostovlandmarksguide.R
import com.example.rostovlandmarksguide.databinding.FragmentWelcomeScreenBinding
import com.example.rostovlandmarksguide.entities.LandmarkEntity
import com.example.rostovlandmarksguide.ml.Model
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

class WelcomeScreenFragment : Fragment() {

    private lateinit var binding: FragmentWelcomeScreenBinding

    private val viewModel: WelcomeScreenViewModel by viewModels()

    private val imageSize = 224

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentWelcomeScreenBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.cameraButton.setOnClickListener(View.OnClickListener {
            if (checkSelfPermission(
                    requireContext(),
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivityForResult(cameraIntent, 3)
            } else {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 100)
            }
        })
        binding.galleryButton.setOnClickListener(View.OnClickListener {
            val cameraIntent =
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(cameraIntent, 1)
        })
    }

    private fun classifyImage(image: Bitmap) {
        try {
            val model: Model = Model.newInstance(requireActivity().applicationContext)

            val image = TensorImage.fromBitmap(image)

// Runs model inference and gets result.
            val outputs = model.process(image)
            val probabilities = outputs.probabilityAsCategoryList
            val maxProbCategory = probabilities.maxBy { it.score }
            val landmarks = LandmarkEntity.readLandmarks(requireContext())
            val landmark = landmarks.find { maxProbCategory.label == it.id.toString() }
//            // Creates inputs for reference.
//            val inputFeature0 =
//                TensorBuffer.createFixedSize(intArrayOf(1, imageSize, imageSize, 3), DataType.FLOAT32)
//            val byteBuffer = ByteBuffer.allocateDirect(4 * imageSize * imageSize * 3)
//            byteBuffer.order(ByteOrder.nativeOrder())
//
//            val intValues = IntArray(imageSize * imageSize)
//            image.getPixels(intValues, 0, image.width, 0, 0, image.width, image.height)
//            var pixel = 0
//            //iterate over each pixel and extract R, G, and B values. Add those values individually to the byte buffer.
//            for (i in 0 until imageSize) {
//                for (j in 0 until imageSize) {
//                    val `val` = intValues[pixel++] // RGB
//                    byteBuffer.putFloat(((`val` shr 16) and 0xFF) * (1f / 1))
//                    byteBuffer.putFloat(((`val` shr 8) and 0xFF) * (1f / 1))
//                    byteBuffer.putFloat((`val` and 0xFF) * (1f / 1))
//                }
//            }
//
//            inputFeature0.loadBuffer(byteBuffer)
//
//// Runs model inference and gets result.
//            val outputs = model.process(inputFeature0)
//            val outputFeature0 = outputs.outputFeature0AsTensorBuffer
//            val confidences = outputFeature0.floatArray
//            // find the index of the class with the biggest confidence.
//            var maxPos = 0
//            var maxConfidence = 0f
//            for (i in confidences.indices) {
//                if (confidences[i] > maxConfidence) {
//                    maxConfidence = confidences[i]
//                    maxPos = i
//                }
//            }
//            binding.result.text = classes[maxPos]
            if (landmark != null) {
                Navigation.findNavController(requireView())
                    .navigate(
                        R.id.action_welcomeScreenFragment_to_landmarkScreenFragment,
                        bundleOf(LANDMARK_KEY to landmark)
                    )
            }
            model.close()
        } catch (e: IOException) {
            // TODO Handle the exception
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == AppCompatActivity.RESULT_OK) {
            if (requestCode == 3) {
                var image = data!!.extras!!["data"] as Bitmap?
                val dimension =
                    min(image!!.width.toDouble(), image.height.toDouble()).toInt()
                image = ThumbnailUtils.extractThumbnail(image, dimension, dimension)
                binding.imageView.setImageBitmap(image)

                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false)
                classifyImage(image.copy(Bitmap.Config.ARGB_8888, true))
            } else {
                val dat = data!!.data
                var image: Bitmap? = null
                try {
                    image =
                        MediaStore.Images.Media.getBitmap(requireActivity().contentResolver, dat)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
                binding.imageView.setImageBitmap(image)

                image = Bitmap.createScaledBitmap(image!!, imageSize, imageSize, false)
                classifyImage(image.copy(Bitmap.Config.ARGB_8888, true))
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    companion object {
        const val LANDMARK_KEY = "LANDMARK_KEY"
    }
}