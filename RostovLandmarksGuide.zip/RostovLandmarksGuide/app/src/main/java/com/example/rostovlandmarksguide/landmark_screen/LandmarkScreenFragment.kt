package com.example.rostovlandmarksguide.landmark_screen

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.example.rostovlandmarksguide.R
import com.example.rostovlandmarksguide.databinding.FragmentLandmarkScreenBinding
import com.example.rostovlandmarksguide.databinding.FragmentWelcomeScreenBinding
import com.example.rostovlandmarksguide.entities.LandmarkEntity
import com.example.rostovlandmarksguide.map_screen.MapScreenFragment
import com.example.rostovlandmarksguide.welcome_screen.WelcomeScreenFragment
import com.google.android.gms.maps.model.LatLng

class LandmarkScreenFragment : Fragment() {

    private lateinit var binding: FragmentLandmarkScreenBinding

    private val viewModel: LandmarkScreenViewModel by viewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLandmarkScreenBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val landmark = arguments?.getParcelable<LandmarkEntity>(WelcomeScreenFragment.LANDMARK_KEY)

        if (landmark!=null) {
            viewModel.landmark = landmark
        }
//            LandmarkEntity(
//            0,
//            name = "Eiffel Tower",
//            geo = LatLng(48.8584, 2.2945),
//            url = "https://www.toureiffel.paris/en",
//            description = "An iconic symbol of France, located in Paris."
//        )
// Настройка TextView
        binding.landmarkName.text = viewModel.landmark.name
        binding.landmarkDescription.text = viewModel.landmark.description

        // Настройка кнопок
        binding.buttonShowOnMap.setOnClickListener {
            // Показать фрагмент карты
            Navigation.findNavController(requireView())
                .navigate(
                    R.id.action_landmarkScreenFragment_to_mapScreenFragment,
                    bundleOf(
                        MapScreenFragment.LATITUDE_KEY to viewModel.landmark.geo?.latitude,
                        MapScreenFragment.LONGITUDE_KEY to viewModel.landmark.geo?.longitude,
                        MapScreenFragment.LOCATION_NAME to viewModel.landmark.name
                    )
                )
        }
        binding.buttonOpenUrl.setOnClickListener {
            // Открытие URL в браузере
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(viewModel.landmark.url))
            startActivity(intent)
        }
    }
}