package com.example.rostovlandmarksguide.entities

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import com.example.rostovlandmarksguide.R
import com.google.android.gms.maps.model.LatLng
import com.opencsv.CSVReader
import java.io.InputStreamReader

data class LandmarkEntity(
    val id: Int,
    val name: String?,
    val geo: LatLng?,
    val url: String?,
    val description: String?,
):Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString(),
        parcel.readParcelable(LatLng::class.java.classLoader),
        parcel.readString(),
        parcel.readString()
    ) {
    }


    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(name)
        parcel.writeParcelable(geo, flags)
        parcel.writeString(url)
        parcel.writeString(description)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<LandmarkEntity> {
        override fun createFromParcel(parcel: Parcel): LandmarkEntity {
            return LandmarkEntity(parcel)
        }

        override fun newArray(size: Int): Array<LandmarkEntity?> {
            return arrayOfNulls(size)
        }

        fun readLandmarks(context: Context): List<LandmarkEntity> {
            val landmarks = mutableListOf<LandmarkEntity>()
            val inputStream = context.resources.openRawResource(R.raw.landmarks)
            val reader = CSVReader(InputStreamReader(inputStream))

            reader.use { csvReader ->
                val header = csvReader.readNext() // Чтение заголовка (если есть)
                var line: Array<String>?

                while (csvReader.readNext().also { line = it } != null) {
                    line?.let {
                        val id = it[0].toInt()
                        val name = it[1]
                        val latitude = it[2].split(", ")[0].toDouble()
                        val longitude = it[2].split(", ")[1].toDouble()
                        val url = it[3]
                        val description = "it[4]"
                        val landmark = LandmarkEntity(
                            id = id,
                            name = name,
                            geo = LatLng(latitude, longitude),
                            url = url,
                            description = description
                        )
                        landmarks.add(landmark)
                    }
                }
            }
            return landmarks
        }
    }
}
