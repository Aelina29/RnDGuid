package com.example.rostovlandmarksguide.landmark_screen

import androidx.lifecycle.ViewModel
import com.example.rostovlandmarksguide.entities.LandmarkEntity

class LandmarkScreenViewModel : ViewModel() {
    lateinit var landmark: LandmarkEntity
}