package com.example.rostovlandmarksguide.welcome_screen

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel

class WelcomeScreenViewModel(application: Application) : AndroidViewModel(application) {

}