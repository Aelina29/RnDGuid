package com.example.rostovlandmarksguide.map_screen

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rostovlandmarksguide.R
import com.example.rostovlandmarksguide.databinding.FragmentLandmarkScreenBinding
import com.example.rostovlandmarksguide.databinding.FragmentMapScreenBinding
import com.example.rostovlandmarksguide.entities.LandmarkEntity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapScreenFragment : Fragment(), OnMapReadyCallback {

    private lateinit var binding: FragmentMapScreenBinding
    private val viewModel: MapScreenViewModel by viewModels()

    private lateinit var map: GoogleMap

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMapScreenBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        val latitude = arguments?.getDouble(LATITUDE_KEY) ?: 0.0
        val longitude = arguments?.getDouble(LONGITUDE_KEY) ?: 0.0
        val title = arguments?.getString(LOCATION_NAME) ?: "Landmark Location"
        val location = LatLng(latitude, longitude)
        val iconAll = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)
        map.addMarker(MarkerOptions().position(location).title(title))

        LandmarkEntity.readLandmarks(requireContext()).forEach {
            if (it.name != title) {
                map.addMarker(MarkerOptions().position(it.geo!!).title(it.name).icon(iconAll))
            }
        }

        map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f))

    }

    companion object {
        const val LATITUDE_KEY = "LATITUDE_KEY"
        const val LONGITUDE_KEY = "LONGITUDE_KEY"
        const val LOCATION_NAME = "LOCATION_NAME"
    }
}