package com.example.rostovlandmarksguide.map_screen

import androidx.lifecycle.ViewModel

class MapScreenViewModel : ViewModel() {
}